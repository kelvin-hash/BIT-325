
package com.eventplanner;
import java.sql.*;
import java.util.*;

public class EventDAO {
    public List<Event> getAllEvents() throws SQLException {
        List<Event> list = new ArrayList<>();
        String sql = "SELECT * FROM events";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Event e = new Event();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setLocation(rs.getString("location"));
                e.setDate(rs.getString("date"));
                e.setDescription(rs.getString("description"));
                list.add(e);
            }
        }
        return list;
    }

    public Event getEventById(int id) throws SQLException {
        Event e = null;
        String sql = "SELECT * FROM events WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                e = new Event();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setLocation(rs.getString("location"));
                e.setDate(rs.getString("date"));
                e.setDescription(rs.getString("description"));
            }
        }
        return e;
    }

    public void addEvent(Event e) throws SQLException {
        String sql = "INSERT INTO events (name, location, date, description) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getName());
            ps.setString(2, e.getLocation());
            ps.setString(3, e.getDate());
            ps.setString(4, e.getDescription());
            ps.executeUpdate();
        }
    }

    public void updateEvent(Event e) throws SQLException {
        String sql = "UPDATE events SET name=?, location=?, date=?, description=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getName());
            ps.setString(2, e.getLocation());
            ps.setString(3, e.getDate());
            ps.setString(4, e.getDescription());
            ps.setInt(5, e.getId());
            ps.executeUpdate();
        }
    }

    public void deleteEvent(int id) throws SQLException {
        String sql = "DELETE FROM events WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
