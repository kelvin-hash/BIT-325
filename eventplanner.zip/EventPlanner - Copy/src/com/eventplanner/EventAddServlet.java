
package com.eventplanner;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

public class EventAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Event e = new Event();
        e.setName(request.getParameter("name"));
        e.setLocation(request.getParameter("location"));
        e.setDate(request.getParameter("date"));
        e.setDescription(request.getParameter("description"));

        try {
            new EventDAO().addEvent(e);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        response.sendRedirect("list");
    }
}
