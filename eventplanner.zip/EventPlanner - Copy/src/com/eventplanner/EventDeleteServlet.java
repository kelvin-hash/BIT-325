
package com.eventplanner;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

public class EventDeleteServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            new EventDAO().deleteEvent(id);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        response.sendRedirect("list");
    }
}
