# XML Project - Group Submission

## Group Members:
- NAME:FARIDI KOMBO    REG NO:SME/B/01-03880/2022
- NAME:Joseph Okoth    REG NO:SME/B/01-03901/2022
- NAME:Joseph Maina    REG NO:SST/B/01-02331/2022
- NAME:Everlyn Mutisya REG NO:SME/B/01-05001/2022
- NAME:Kelvin Mungai   REG NO:SIT/B/01-03492/2022

## Project Description:
This project contains XML files demonstrating [].



## How to Use:
Open the XML files using any text editor or XML viewer. Each file follows the required schema and structure for the assignment.
